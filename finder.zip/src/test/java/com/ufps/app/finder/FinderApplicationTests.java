package com.ufps.app.finder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
